package t3final;

public class variablesGlobales {
	public static String nombreUsuario = "Invitado";
    public static int contadorClicks = 0;
    public static boolean modoOscuro = false;
}
